local composer = require( "composer" )
local physics = require( "physics")
local widget = require("widget")
local audio = require("audio")
local sqlite3 = require("sqlite3")
local gameNetwork = require( "gameNetwork" )
local playerName
local a1 = "CggIt7LawRwQAhAJ"

--physics.setGravity( 0, 0 )

local scene = composer.newScene()
local background
local patch
local ground
local scoreTextt
local hs
local ns
local button1
local lead
local ach
local panel
local rate
panelg = display.newGroup( )


-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------
local function loadLocalPlayerCallback( event )
  playerName = event.data.alias
end

local function gameNetworkLoginCallback( event )
  gameNetwork.request( "loadLocalPlayer", { listener=loadLocalPlayerCallback } )
  return true
end

local function gpgsInitCallback( event )
  gameNetwork.request( "login", { userInitiated=true, listener=gameNetworkLoginCallback } )
end

local function gameNetworkSetup()
  if ( system.getInfo("platformName") == "Android" ) then
    gameNetwork.init( "google", gpgsInitCallback )
  else
    gameNetwork.init( "gamecenter", gameNetworkLoginCallback )
  end
end

local function systemEvents( event )
  print("systemEvent " .. event.type)
  if ( event.type == "applicationSuspend" ) then
    print( "suspending..........................." )
  elseif ( event.type == "applicationResume" ) then
    print( "resuming............................." )
  elseif ( event.type == "applicationExit" ) then
    print( "exiting.............................." )
  elseif ( event.type == "applicationStart" ) then
    gameNetworkSetup()  --login to the network here
  end
  return true
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------
-- create()
local sel
local function go(event)
  if(event.phase == "ended") then
    composer.gotoScene("instruction",  {effect = "fade", time = 200})
  end
end

local function showLeaderboards( event )
  if(event.phase == "ended") then
    if ( system.getInfo("platformName") == "Android" ) then
      gameNetwork.show( "leaderboards" )
    else
      gameNetwork.show( "leaderboards", { leaderboard = {timeScope="AllTime"} } )
    end
  end

  return true
end

local function showAchievements(event)
  if(event.phase == "ended") then
    gameNetwork.show( "achievements" )
  end
  return true
end



local function rate(event)
  if(event.phase == "began") then 
    event.target.alpha = 0.5
  elseif(event.phase == "moved") then
    event.target.alpha = 0.9
    print(tostring("x:" .. event.x .. " " .. "y:".. event.y))
  elseif (event.phase == "ended") then
    event.target.alpha = 0.9
    system.openURL( "https://play.google.com/store/apps/details?id=com.bitgames.Tappy_Blob" )
  end
end

function scene:create( event )
  local sceneGroup = self.view
  if ( system.getInfo( "platformName" ) == "Android" ) then
    interstitialAppID = "ca-app-pub-1989983877888544/4039356914"
    bannerAppID = "ca-app-pub-1989983877888544/6328942517"
    --ads.init( adProvider, bannerAppID, adListener )
    
  end
  panelg.alpha = 0.9
  local ss = 0

  -----------------------------------------------------------------------------------
  path = system.pathForFile( "scores.db", system.DocumentsDirectory )
  db = sqlite3.open(path)
  -----------------------------------------------------------------------------------
  -- Code here runs when the scene is first created but has not yet appeared on screen
   background1 = display.newImageRect("nightsky.png", display.contentWidth, display.contentHeight )
   background1.anchorY = 1
   background1.x = display.contentCenterX 
   background1.y = display.actualContentHeight
   
  
  local mount1 = display.newImageRect("mount.png", display.contentWidth * 0.24, display.contentHeight * 0.24 )
  mount1.anchorX = 0
  mount1.anchorY = 1
  local mount2 = display.newImageRect("mount.png", display.contentWidth * 0.28, display.contentHeight * 0.28 )
  mount2.anchorX = 0
  mount2.anchorY = 1

  local mount3 = display.newImageRect("mount.png", display.contentWidth * 0.28, display.contentHeight * 0.28 )
  mount3.anchorX = 0
  mount3.anchorY = 1

  local mount4 = display.newImageRect("mount.png", display.contentWidth * 0.24, display.contentHeight * 0.24 )
  mount4.anchorX = 0
  mount4.anchorY = 1

  mount4.x = display.contentWidth * 0.75
  mount4.y = display.contentHeight


  mount3.x = display.contentWidth * 0.50
  mount3.y = display.contentHeight


  mount2.x = 0
  mount2.y = display.contentHeight

  mount1.x = mount2.width - mount2.width * 0.07
  mount1.y = display.contentHeight
  mount1.alpha = 0.8


  patch = display.newImageRect( "streetblock.png", display.actualContentWidth,  display.contentHeight * 0.17 )
  patch.x = display.contentCenterX
  patch.y = display.contentHeight * 0.975
  
  ground = display.newImageRect("candy.png", display.contentWidth, display.contentHeight * 0.17 )
  ground.x = display.contentCenterX
  ground.y = display.contentHeight * 0.99


  scoreTextt = display.newText("GAME OVER", display.contentCenterX, display.contentHeight * 0.10, "ka1", display.contentWidth * 0.10)
  scoreTextt.x = display.contentCenterX
  scoreTextt.y = display.actualContentHeight * 0.15

  ns = display.newText("", display.contentCenterX, display.contentHeight * 0.10, "ka1", 23)
  ns.x = display.contentWidth * 0.45
  ns.y = display.actualContentHeight * 0.35


  hs = display.newText("", display.contentCenterX, display.contentHeight * 0.10, "ka1", 23)
  hs.x = display.contentCenterX
  hs.y = display.actualContentHeight * 0.45
  for row in db:nrows("SELECT * FROM highscores") do
    hs.text = "BEST              " .. row.hs 
    ns.text = "SCORE      ".. event.params.s
  end


  button1 = widget.newButton(
    {
      width = display.contentWidth * 0.35,
      height =  display.contentHeight * .11 ,
      defaultFile = "replay_normal.png",
      overFile = "replay_pressed.png",
      onEvent = go

    }
  )


  button1.x = display.contentCenterX
  button1.y = display.contentHeight * 0.60

  lead = widget.newButton(
    {
      width = display.contentHeight *.10,
      height =  display.contentHeight * .10 ,
      defaultFile = "a_normal.png",
      overFile = "a_pressed.png",
      onEvent = showLeaderboards

    }
  )

  lead.x = display.actualContentWidth * 0.85
  lead.y = display.contentHeight * 0.74

  ach = widget.newButton(
    {
      width = display.contentHeight *.10,
      height =  display.contentHeight * .10 ,
      defaultFile = "ach_normal.png",
      overFile = "ach_pressed.png",
      onEvent = showAchievements

    }
  )

  ach.x = display.actualContentWidth * 0.15
  ach.y = display.contentHeight * 0.74

  panel = display.newImageRect(panelg, "panel.png", display.contentWidth * .95, display.contentHeight * 0.50 )
  panel.x = display.contentCenterX
  panel.y = display.contentCenterY
  panel.alpha = 0.2

  rate = widget.newButton(
    {
      width = display.contentHeight *.20,
      height =  display.contentHeight * .09 ,
      defaultFile = "button_rate.png",
      overFile = "button_rate.png",
      onEvent = rate

    }
  )
  rate.x = display.contentCenterX
  rate.y = display.contentHeight * 0.80
  rate.alpha = 9

  panelg:insert(button1)
  panelg:insert(ns)
  panelg:insert( hs )
  panelg:insert(ach)
  panelg:insert(lead)
  panelg:insert(rate)

  sceneGroup:insert( background1)
  sceneGroup:insert(mount4)
  sceneGroup:insert(mount3)
  sceneGroup:insert( mount2 )
  sceneGroup:insert(mount1)
  sceneGroup:insert(patch)
  sceneGroup:insert(scoreTextt)
  sceneGroup:insert(ground)
  sceneGroup:insert(panelg)
  
 
  
end


-- show()
function scene:show( event )

  local sceneGroup = self.view
  local phase = event.phase

  if ( phase == "will" ) then
    -- Code here runs when the scene is still off screen (but is about to come on screen)
    
  elseif ( phase == "did" ) then
    --
  end
end


-- hide()
function scene:hide( event )

  local sceneGroup = self.view
  local phase = event.phase

  if ( phase == "will" ) then
    -- Code here runs when the scene is on screen (but is about to go off screen)

  elseif ( phase == "did" ) then

    composer.removeScene("gameover")
   
   
    db:close( )

    -- Code here runs immediately after the scene goes entirely off screen
  end
end


-- destroy()
function scene:destroy( event )

  local sceneGroup = self.view
  --Runtime:removeEventListener("tap", showLeaderboards )
  -- Code here runs prior to the removal of scene's view

end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
Runtime:addEventListener( "system", systemEvents )
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-- -----------------------------------------------------------------------------------

return scene