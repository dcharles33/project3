local composer = require( "composer" )
local audio = require("audio")


local scene = composer.newScene()
local displayText
local it
local it3
local it2
local left
local right
local tut
local monster
local background


---------------------------------------------------------------------------------
-- All code outside of the listener functions will only be executed ONCE
-- unless "composer.removeScene()" is called.
---------------------------------------------------------------------------------

-- local forward references should go here

---------------------------------------------------------------------------------

-- "scene:create()"
local function go()
  composer.gotoScene( "gamescreen", {effect = "crossFade", time = 300} )
end 
function scene:create( event )

  local sceneGroup = self.view
  background1 = display.newImageRect("nightsky.png", display.contentWidth, display.contentHeight )
  background1.anchorY = 1
  background1.x = display.contentCenterX 
  background1.y = display.actualContentHeight

  local mount1 = display.newImageRect("mount.png", display.contentWidth * 0.24, display.contentHeight * 0.24 )
  mount1.anchorX = 0
  mount1.anchorY = 1
  local mount2 = display.newImageRect("mount.png", display.contentWidth * 0.28, display.contentHeight * 0.28 )
  mount2.anchorX = 0
  mount2.anchorY = 1

  local mount3 = display.newImageRect("mount.png", display.contentWidth * 0.28, display.contentHeight * 0.28 )
  mount3.anchorX = 0
  mount3.anchorY = 1

  local mount4 = display.newImageRect("mount.png", display.contentWidth * 0.24, display.contentHeight * 0.24 )
  mount4.anchorX = 0
  mount4.anchorY = 1

  mount4.x = display.contentWidth * 0.75
  mount4.y = display.contentHeight


  mount3.x = display.contentWidth * 0.50
  mount3.y = display.contentHeight


  mount2.x = 0
  mount2.y = display.contentHeight

  mount1.x = mount2.width - mount2.width * 0.07
  mount1.y = display.contentHeight
  mount1.alpha = 0.8

  displayText = display.newText("How To Play", display.contentWidth * 0.50, display.contentHeight * 0.15, "ka1.ttf", display.contentWidth * 0.10 )
  displayText.x = display.contentCenterX
  displayText.y = display.contentCenterY * 0.40




  tut = display.newImageRect("tut.png", display.contentWidth * 0.666, display.contentWidth * 0.666)
  tut.y = display.contentHeight * 0.65
  tut.x = display.contentCenterX

  monster = display.newImageRect( "monster.png", display.contentWidth * 0.22, display.contentWidth * 0.22 )
  monster.x = display.contentWidth * 0.560
  monster.y = display.contentHeight * 0.50

  patch = display.newImageRect( "streetblock.png", display.actualContentWidth,  display.contentHeight * 0.17 )
  patch.x = display.contentCenterX
  patch.y = display.contentHeight * 0.975


  ground = display.newImageRect("candy.png", display.contentWidth, display.contentHeight * 0.17 )
  ground.x = display.contentCenterX
  ground.y = display.contentHeight * 0.99

  sceneGroup:insert(background1)
  sceneGroup:insert(mount4)
  sceneGroup:insert(mount3)
  sceneGroup:insert( mount2 )
  sceneGroup:insert(mount1)
  sceneGroup:insert( displayText )
  sceneGroup:insert(tut)
  sceneGroup:insert( monster )
  sceneGroup:insert(patch )
  sceneGroup:insert(ground )





  -- Initialize the scene here.
  -- Example: add display objects to "sceneGroup", add touch listeners, etc.
end

-- "scene:show()"
function scene:show( event )

  local sceneGroup = self.view
  local phase = event.phase

  if ( phase == "will" ) then

    -- Called when the scene is still off screen (but is about to come on screen).
  elseif ( phase == "did" ) then
    -- Called when the scene is now on screen.
    -- Insert code here to make the scene come alive.
    -- Example: start timers, begin animation, play audio, etc.

    Runtime:addEventListener( "tap", go )
  end
end

-- "scene:hide()"
function scene:hide( event )

  local sceneGroup = self.view
  local phase = event.phase

  if ( phase == "will" ) then
    -- Called when the scene is on screen (but is about to go off screen).
    -- Insert code here to "pause" the scene.
    -- Example: stop timers, stop animation, stop audio, etc.
  elseif ( phase == "did" ) then
    composer.removeScene( "instruction" )

    -- Called immediately after scene goes off screen.
  end
end

-- "scene:destroy()"
function scene:destroy( event )

  local sceneGroup = self.view
  Runtime:removeEventListener( "tap", go )
  -- Called prior to the removal of scene's view ("sceneGroup").
  -- Insert code here to clean up the scene.
  -- Example: remove display objects, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

---------------------------------------------------------------------------------

return scene