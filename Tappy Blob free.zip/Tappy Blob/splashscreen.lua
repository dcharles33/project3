local audio = require("audio")
local sqlite3 = require("sqlite3")
local composer = require( "composer" )
local physics = require("physics")
physics.start( )
display.setStatusBar(display.HiddenStatusBar)
local scene = composer.newScene()
local namet
local gametimer
local path

local background1

local z
local y
local x
------------------------------------------------------------------------------------
display.setDefault( "anchorX", 0.5 )
display.setDefault( "anchorY", 0.5 )
-- -----------------------------------------------------------------------------------

---------------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

function scene:create( event )

  local sceneGroup = self.view

  ------------------------------------------------------------------------------------------

  background1 = display.newImageRect("nightsky.png", display.contentWidth, display.contentHeight )
  background1.anchorY = 1
  background1.x = display.contentCenterX 
  background1.y = display.actualContentHeight



  namet = display.newText("Bit Games", display.contentCenterX, display.contentHeight * 0.10, "ka1", display.contentWidth * 0.14)
  namet.x = display.contentCenterX
  namet.y = display.contentCenterY
  local s = 0
  local tableExists = false
  
  ---------------------------------------------------------------------------------------------
  sceneGroup:insert(background1)
  sceneGroup:insert(namet)

end


-- show()
local function onliste(  )
  composer.gotoScene( "selection", {effect = "crossFade", time = 750})
end

function scene:show( event )

  local sceneGroup = self.view
  local phase = event.phase

  if ( phase == "will" ) then
    -- Code here runs when the scene is still off screen (but is about to come on screen)

  elseif ( phase == "did" ) then
    gametimer = timer.performWithDelay( 2000, onliste, 1 )
  end
end


-- hide()
function scene:hide( event )

  local sceneGroup = self.view
  local phase = event.phase

  if ( phase == "will" ) then
    -- Code here runs when the scene is on screen (but is about to go off screen)

  elseif ( phase == "did" ) then
    -- Code here runs immediately after the scene goes entirely off screen
    composer.removeScene( "splashscreen")

  end
end


-- destroy()
function scene:destroy( event )

  local sceneGroup = self.view

  -- Code here runs prior to the removal of scene's view

end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene