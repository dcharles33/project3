local sqlite3 = require("sqlite3")
local composer = require( "composer" )
local physics = require("physics")
local audio = require("audio")
--local bb = require( "bb" )
local whoshSoundID = media.newEventSound("")
--media.playEventSound(whoshSoundID)

local scene = composer.newScene()

physics.start( )
physics.setGravity( 0, 0 )
display.setStatusBar(display.HiddenStatusBar)
local sel
local sel2
local sp
local pp

local scoreText
local ground
local mount
local scoreLoop
local gameloop
local DELAY = 5000
local SCOREDELAY
local score = 0
local counter = 0
local backgroup
local gamegroup
local uigroup
local forgroup
local vx, vy
local leftTunnels
local rightTunnels

local path
local db
local instr

local glove

local a1
local a2 
local a3
local a4
local a5 

local ob;

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------




local myAchievement
local function postScoreSubmit( event )
   --whatever code you need following a score submission...
   return true
end

local function achievementRequestCallback( )
	-- body
end

function una()
	if (score == 5) then
   		myAchievement = "com.yourname.yourapp.achivementname"
		if ( system.getInfo("platformName") == "Android" ) then
   			--for GPGS, reset "myAchievement" to the string provided from the achievement setup in Google
   			myAchievement = a1
		end
 
		gameNetwork.request( "unlockAchievement",
		{
   		achievement = { identifier=myAchievement, percentComplete=100, showsCompletionBanner=true },
   		listener = achievementRequestCallback
		} )
		
   	elseif (score == 20) then
   		myAchievement = "com.yourname.yourapp.achivementname"
		if ( system.getInfo("platformName") == "Android" ) then
   			--for GPGS, reset "myAchievement" to the string provided from the achievement setup in Google
   			myAchievement = a2
		end
 
		gameNetwork.request( "unlockAchievement",
		{
   		achievement = { identifier=myAchievement, percentComplete=100, showsCompletionBanner=true },
   		listener = achievementRequestCallback
		} )
   		
   	elseif (score == 50) then 
   		myAchievement = "com.yourname.yourapp.achivementname"
		if ( system.getInfo("platformName") == "Android" ) then
   			--for GPGS, reset "myAchievement" to the string provided from the achievement setup in Google
   			myAchievement = a3
		end
 
		gameNetwork.request( "unlockAchievement",
		{
   		achievement = { identifier=myAchievement, percentComplete=100, showsCompletionBanner=true },
   		listener = achievementRequestCallback
		} )
   		
   	elseif (score == 100) then
   		myAchievement = "com.yourname.yourapp.achivementname"
		if ( system.getInfo("platformName") == "Android" ) then
   			--for GPGS, reset "myAchievement" to the string provided from the achievement setup in Google
   			myAchievement = a4
		end
 
		gameNetwork.request( "unlockAchievement",
		{
   		achievement = { identifier=myAchievement, percentComplete=100, showsCompletionBanner=true },
   		listener = achievementRequestCallback
		} )
   		
   	elseif (score == 1000) then
   		myAchievement = "com.yourname.yourapp.achivementname"
		if ( system.getInfo("platformName") == "Android" ) then
   			--for GPGS, reset "myAchievement" to the string provided from the achievement setup in Google
   			myAchievement = a5
		end
 
		gameNetwork.request( "unlockAchievement",
		{
   		achievement = { identifier=myAchievement, percentComplete=100, showsCompletionBanner=true },
   		listener = achievementRequestCallback
		} )
	end
end

local function countScore()
	pp = audio.play(sp)
	score = score + 1
	scoreText.text = score
	counter = counter + 1
	una()
end

local function removeTunnel()
	for i = #leftTunnels, 1, -1 do
		local thisLeftTunnel = leftTunnels[i]
		if (thisLeftTunnel.y >= display.contentHeight + thisLeftTunnel.height) then
			display.remove( thisLeftTunnel)
			table.remove( leftTunnels, i)
			
		end
	end

	for i = #rightTunnels, 1, -1 do
		local thisRightTunnel = rightTunnels[i]
		if (thisRightTunnel.y >= display.contentHeight + thisRightTunnel.height) then
			display.remove( thisRightTunnel )
			table.remove( rightTunnels, i)
			
		end
	end
end

local function removeAllTunnel( )
	for i = #leftTunnels, 1, -1 do
		local thisLeftTunnel = leftTunnels[i]
		if(thisLeftTunnel ~= nil) then
			display.remove( thisLeftTunnel )
	    	table.remove( leftTunnels, i)
	    end
	end

	for i = #rightTunnels, 1, -1 do
		local thisRightTunnel = rightTunnels[i]
		if(thisRightTunnel ~= nil) then
			display.remove( thisRightTunnel )
			table.remove( rightTunnels, i)
		end	
	end
end

local function r(target)
	display.remove(target)
end

local function createTunnel()
	local md = math.random( -display.contentWidth * .19, display.contentWidth * .19 )
	leftTunnel = display.newImageRect( gamegroup, "00.png", display.contentWidth * .60, display.contentHeight * 0.07)
	leftTunnel.x = display.contentWidth * 0.09
	leftTunnel:translate( md, 0 ) 
	leftTunnel.y = -leftTunnel.height
	leftTunnel.anchorX = 0.5
	leftTunnel.anchorY = 1
	leftTunnel.myName = "tunnel1"
	physics.addBody( leftTunnel, "dynamic", { friction=0.5, bounce=0 })
	transition.to( leftTunnel, {time = DELAY, y = display.contentHeight + leftTunnel.height, onComplete = r} )
	table.insert( leftTunnels, leftTunnel )

	rightTunnel = display.newImageRect( gamegroup, "11.png", display.contentWidth * .60,  display.contentHeight * 0.07)
	rightTunnel.x = display.contentWidth + display.contentWidth * 0.09
	rightTunnel:translate( md, 0 )
	rightTunnel.y = -rightTunnel.height
	rightTunnel.anchorX = 0.5
	rightTunnel.anchorY = 1
	rightTunnel.myName = "tunnel2"
	physics.addBody(rightTunnel, "dynamic", { friction=0.5, bounce=0 })
	transition.to( rightTunnel, {time = DELAY, y = display.contentHeight + rightTunnel.height, onComplete = r} )
	table.insert( rightTunnels, rightTunnel )
	
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
local function go()
	local options =
    {
    effect = "slideUp",
    time = 450,
    params =
    {
        s = score
    }
}
	composer.gotoScene( "gameover", options )
end 

local function onCollision( event )
	if ( event.phase == "began") then
		 ------------------------------------------------------------------------------------
		path = system.pathForFile( "bitgames_blob.db", system.DocumentsDirectory )
    	db = sqlite3.open(path)
    	----------------------------------------------------------------------------
    	for row in db:nrows("SELECT * FROM stats") do
       	   if(score >= row.score) then
       	   	local q = [[UPDATE stats SET score =]] .. score .. [[;]]
       	   	db:exec(q)
       	   	
       	   end
       end
       db:close( )
       --local stopper2 = timer.cancel( scoreLoop )
       local s =  audio.play(sel2)
       removeAllTunnel()
       go()
    end

end
local function outb()
	if(monster.x < monster.width / 2 or monster.x  > display.contentWidth - (monster.width / 2) )then
		path = system.pathForFile( "bitgames_blob.db", system.DocumentsDirectory )
    	db = sqlite3.open(path)
    	----------------------------------------------------------------------------
    	for row in db:nrows("SELECT * FROM stats") do
       	   if(score >= row.score) then
       	   	local q = [[UPDATE stats SET score =]] .. score .. [[;]]
       	   	db:exec(q)
       	   	
       	   end
       end
       db:close( )
       --local stopper2 = timer.cancel( scoreLoop )
       local s =  audio.play(sel2)
       removeAllTunnel()
       go()
	end
	
	
end 
   
function scene:create( event )
	sceneGroup = self.view
	if ( system.getInfo( "platformName" ) == "Android" ) then
        --for GPGS, reset "myCategory" to the string provided from the leaderboard setup in Google
    	myCategory = "CgkI0s-kmPMNEAIQCg"
    end
    if ( system.getInfo("platformName") == "Android" ) then
   			--for GPGS, reset "myAchievement" to the string provided from the achievement setup in Google
   		a1 = "CgkI0s-kmPMNEAIQBQ"
		a2 = "CgkI0s-kmPMNEAIQBg"
		a3 = "CgkI0s-kmPMNEAIQBw"
		a4 = "CgkI0s-kmPMNEAIQCA"
		a5 = "CgkI0s-kmPMNEAIQCQ" 
	end

	leftTunnels = {}
	rightTunnels = {}
	
	backgroup = display.newGroup( )
	gamegroup = display.newGroup( )
	uigroup = display.newGroup( )

	-- Code here runs when the scene is first created but has not yet appeared on screen
    
    monster = display.newImageRect( gamegroup, "monster.png", display.contentWidth * 0.12, display.contentWidth * 0.12 )
	monster.x = display.contentCenterX
	monster.y = display.contentHeight * 0.50
	physics.addBody(monster, "dynamic")
	
	monster.rotation = 0
	monster.myName = "monster"
	
	scoreText = display.newText( uigroup, score, display.contentCenterX, display.contentHeight * 0.10, "ka1", 35)
	
	sceneGroup:insert(backgroup)
	sceneGroup:insert(gamegroup)
	createTunnel()
	sceneGroup:insert(uigroup)
	
end

local function t()
	local gn = audio.play( sel)
	
	vx, vy = monster:getLinearVelocity()
	if(monster.xScale == 1) then 

		monster.xScale = -1

	elseif (monster.xScale == -1) then
		monster.xScale = 1
	end
	monster:setLinearVelocity(vx * -1, 0, monster.x, monster.y)
end

function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
    	sel = audio.loadSound( "turn.wav")
        sel2 = audio.loadSound( "slap.wav" )
        sp = audio.loadSound("scorep.wav")
        Runtime:addEventListener("collision", onCollision)

        -- Code here runs when the scene is still off screen (but is about to come on screen)
    elseif ( phase == "did" ) then
    	Runtime:addEventListener( "tap", t )
        -- Code here runs when the scene is entirely on screen
       local random = math.random( 1,2 )
		if(random == 1) then
			monster.xScale = 1
			monster:setLinearVelocity( 200, 0 )
		elseif (random == 2) then
			monster.xScale = -1
			monster:setLinearVelocity( -200, 0 )
		end
        gameloop = timer.performWithDelay( 2500, createTunnel, -1 )
        scoreLoop = timer.performWithDelay(2500, countScore, -1 )
        ob = timer.performWithDelay( 50, outb, -1 )
       
    end
end

function scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
        local stop = timer.cancel( gameloop )
    	local stop2 = timer.cancel( scoreLoop )
        local stop3 = timer.cancel( ob )
   
    	
    elseif ( phase == "did" ) then
    	 gameNetwork.request( "setHighScore",
			{
   				localPlayerScore = { category=myCategory, value=tonumber(score) },
   				listener = postScoreSubmit
			} )
    	composer.removeScene("gamescreen")
    	Runtime:removeEventListener("tap", t)
    	Runtime:removeEventListener("collision", onCollision)
        
    end
end

function scene:destroy( event )
	leftTunnels = nil
    rightTunnels = nil
    local sceneGroup = self.view
    audio.stop(pp)
    pp = nil

    -- Code here runs prior to the removal of scene's view

end
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
return scene