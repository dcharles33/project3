-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local audio = require("audio")
local gameNetwork = require( "gameNetwork" )
local composer = require( "composer" )
local scene = composer.newScene()

local physics = require( "physics" )
physics.start( )
physics.start( )
physics.setGravity( 0, 0 )

local widget = require("widget")

display.setStatusBar(display.HiddenStatusBar)
display.setDefault( "anchorX", 0.5 )    -- default to Center anchor point for new objects
display.setDefault( "anchorY", 0.5 )
local playerName
local a1 = "CgkI0s-kmPMNEAIQBA"

local backgroup = display.newGroup( )
local centergroup = display.newGroup( )
local forgroup = display.newGroup( )
local uigroup = display.newGroup( )
local patch
local ground
local ground2
local ground3
local mount
local displayText
local button1
local background
local mountain1
local lead
local ach


local function loadLocalPlayerCallback( event )
   playerName = event.data.alias
end
 
local function gameNetworkLoginCallback( event )
   gameNetwork.request( "loadLocalPlayer", { listener=loadLocalPlayerCallback } )
   return true
end
 
local function gpgsInitCallback( event )
   gameNetwork.request( "login", { userInitiated=true, listener=gameNetworkLoginCallback } )
end
 
local function gameNetworkSetup()
   if ( system.getInfo("platformName") == "Android" ) then
      gameNetwork.init( "google", gpgsInitCallback )
   else
      gameNetwork.init( "gamecenter", gameNetworkLoginCallback )
   end
end
 
------HANDLE SYSTEM EVENTS------
local function systemEvents( event )
   print("systemEvent " .. event.type)
   if ( event.type == "applicationSuspend" ) then
      print( "suspending..........................." )
   elseif ( event.type == "applicationResume" ) then
      print( "resuming............................." )
   elseif ( event.type == "applicationExit" ) then
      print( "exiting.............................." )
   elseif ( event.type == "applicationStart" ) then
      gameNetworkSetup()  --login to the network here
   end
   return true
end
local function showLeaderboards(event )
   if ( system.getInfo("platformName") == "Android" ) then
       if(event.phase == "ended") then
          gameNetwork.show( "leaderboards" )
       end
   
      --gameNetwork.show( "leaderboards", { leaderboard = {timeScope="AllTime"} } )
    end
end

local function showAchievements(event)
  if(event.phase == "ended") then
    gameNetwork.show( "achievements" )
  end
   return true
end

local function gameLoop( )
  if(ground.x < -display.contentCenterX) then 
        ground:translate(display.contentCenterX * 4, 0)
    elseif (ground2.x < -display.contentCenterX) then 
        ground2:translate(display.contentCenterX * 4, 0)
    elseif (ground3.x < -display.contentCenterX ) then
        ground3:translate( display.contentCenterX * 4, 0 )
    end
  -- body
end

local function go(event)
  
  if(event.phase == "ended") then
    composer.gotoScene( "instruction", {effect = "slideLeft", time = 555})
    
  end
end

function scene:create( event )
   local sceneGroup = self.view
   
   --background = display.newImageRect( backgroup, "nightsky.png", display.actualContentWidth, display.actualContentHeight )
   --background.x = display.contentCenterX
   --background.y = display.contentCenterY
   
   local mount1 = display.newImageRect( backgroup, "mount.png", display.contentWidth * 0.24, display.contentHeight * 0.24 )
   mount1.anchorX = 0
   mount1.anchorY = 1
   local mount2 = display.newImageRect( backgroup, "mount.png", display.contentWidth * 0.28, display.contentHeight * 0.28 )
   mount2.anchorX = 0
   mount2.anchorY = 1

   local mount3 = display.newImageRect( backgroup, "mount.png", display.contentWidth * 0.28, display.contentHeight * 0.28 )
   mount3.anchorX = 0
   mount3.anchorY = 1

   local mount4 = display.newImageRect( backgroup, "mount.png", display.contentWidth * 0.24, display.contentHeight * 0.24 )
   mount4.anchorX = 0
   mount4.anchorY = 1
   
   patch = display.newImageRect( backgroup, "streetblock.png", display.actualContentWidth,  display.contentHeight * 0.17 )
   patch.x = display.contentCenterX
   patch.y = display.contentHeight * 1.01

   mount4.x = display.contentWidth * 0.75
   mount4.y = display.contentHeight
   

   mount3.x = display.contentWidth * 0.50
   mount3.y = display.contentHeight
    
   
   mount2.x = 0
   mount2.y = display.contentHeight
   
   mount1.x = mount2.width - mount2.width * 0.07
   mount1.y = display.contentHeight
   mount1.alpha = 0.8
   
   ground = display.newImageRect( forgroup, "candy.png", display.contentWidth, display.contentHeight * 0.17 )
   ground.x = display.contentCenterX
   ground.y = display.contentHeight * 1.02
   ground2 = display.newImageRect( forgroup, "candy.png", display.contentWidth, display.contentHeight * 0.17 )
   ground2.x = display.contentWidth + display.contentCenterX
   ground2.y = display.contentHeight * 1.02
   ground3 = display.newImageRect( forgroup, "candy.png", display.contentWidth, display.contentHeight * 0.17 )
   ground3.x = display.contentWidth * display.contentCenterX * 3
   ground3.y = display.contentHeight * 1.02
   

   displayText = display.newText( uigroup, "Tappy Glob", display.contentWidth * 0.50, display.contentHeight * 0.15, "ka1.ttf", display.contentWidth * 0.11 )
   displayText.x = display.contentCenterX
   displayText.y = display.contentCenterY * 0.40

   displayText = display.newText( uigroup, "(C) Bit Games 2016", display.contentWidth * 0.50, display.contentHeight * 0.15, "ka1.ttf", display.contentWidth * 0.05 )
   displayText.x = display.contentCenterX
   displayText.y = display.contentHeight * 0.975

   button1 = widget.newButton(
   {
        width = display.contentWidth * 0.35,
        height =  display.contentHeight * .10 ,
        defaultFile = "button_normal.png",
        overFile = "button_pressed.png",
        onEvent = go
        
    }
  )
   button1.x = display.contentCenterX
   button1.y = display.contentHeight * 0.50

   button1.alpha = 0.7

 lead = widget.newButton(
   {
        width = display.contentHeight *.10,
        height =  display.contentHeight * .10 ,
        defaultFile = "a_normal.png",
        overFile = "a_pressed.png",
        onEvent = showLeaderboards
        
    }
  )

   lead.x = display.actualContentWidth * 0.80
   lead.y = display.contentHeight * 0.69
   lead.alpha = 0.7

    ach = widget.newButton(
   {
        width = display.contentHeight *.10,
        height =  display.contentHeight * .10 ,
        defaultFile = "ach_normal.png",
        overFile = "ach_pressed.png",
        onEvent = showAchievements
        
    }
  )

   ach.x = display.actualContentWidth * 0.20
   ach.y = display.contentHeight * 0.69
   ach.alpha = 0.7

   physics.addBody( ground, "dynamic" )
   physics.addBody( ground2, "dynamic" )
   physics.addBody( ground3, "dynamic" )

   sceneGroup:insert( backgroup )
   sceneGroup:insert( centergroup )
   sceneGroup:insert( forgroup)
   sceneGroup:insert(uigroup)
   sceneGroup:insert(button1)
   sceneGroup:insert( lead )
   sceneGroup:insert(ach)
   

end

 
-- "scene:show()"
function scene:show( event )
   local sceneGroup = self.view
   local phase = event.phase
 
   if ( phase == "will" ) then
      -- Called when the scene is still off screen (but is about to come on screen).
     
    elseif ( phase == "did" ) then

    

      -- Called when the scene is now on screen.
      -- Insert code here to make the scene come alive.
      -- Example: start timers, begin animation, play audio, etc.
      gameNetwork.request( "unlockAchievement",{ achievement = { identifier=a1, percentComplete=100, showsCompletionBanner=true }, listener = achievementRequestCallback} )
      ground:setLinearVelocity(-20, 0 )   
      ground2:setLinearVelocity(-20, 0 )
      ground3:setLinearVelocity(-20, 0 )
      gameLoopTimer = timer.performWithDelay(500, gameLoop, 0 )
      
      
    end
end
 
-- "scene:hide()"
function scene:hide( event )
   local sceneGroup = self.view
   local phase = event.phase
 
   if ( phase == "will" ) then
      -- Called when the scene is on screen (but is about to go off screen).
      -- Insert code here to "pause" the scene.
      -- Example: stop timers, stop animation, stop audio, etc.
      stopgame = timer.cancel( gameLoopTimer )

      
   elseif ( phase == "did" ) then
     Runtime:removeEventListener( "system", systemEvents )
     composer.removeScene( "selection" )
   


      -- Called immediately after scene goes off screen.
    end
end
 
-- "scene:destroy()"
function scene:destroy( event )
   local sceneGroup = self.view
   
   
   -- Called prior to the removal of scene's view ("sceneGroup").
   -- Insert code here to clean up the scene.
   -- Example: remove display objects, save state, etc.
   
   
 end
---------------------------------------------------------------------------------
-- Listener setup
Runtime:addEventListener( "system", systemEvents )
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

---------------------------------------------------------------------------------
return scene